import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import g4p_controls.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class flocking extends PApplet {

final float BOID_RADIUS = 2.5f;
final float BOID_VICINITY = 45.0f;

class Boid {  
  PVector position;
  PVector velocity;

  float maxSpeed = 2;
  float obstacleLookahead = 20.0f;

  Boid(float x, float y) {
    position = new PVector(x, y);
    velocity = PVector.random2D();
  }

  public void run(ArrayList<Boid> boids, ArrayList<Obstacle> obstacles) {
    PVector vel = updateBoid(boids, obstacles);
    vel.normalize();
    velocity.add(vel);
    
    move();
    borders();
    render();
  }

  public PVector updateBoid(ArrayList<Boid> boids, ArrayList<Obstacle> obstacles) {
    ArrayList<Boid> neighbors = findNeighbors(boids, BOID_VICINITY);
    ArrayList<Predator> closePredators = findClosePredators(boids);

    PVector sep = calculateSeparationForce(neighbors);
    PVector align = calculateAlignmentForce(neighbors);
    PVector coh = calculateCohesionForce(neighbors);
    PVector avoid = calculateAvoidanceForce(obstacles);
    PVector escape = calculateEscapeForce(closePredators);
    
    sep.mult(separationWeight);
    align.mult(alignmentWeight);
    coh.mult(cohesionWeight);
    avoid.mult(avoidanceWeight);         
    escape.mult(escapeWeight);
      
    PVector vel = new PVector(0,0);    
    vel.add(sep);
    vel.add(align);
    vel.add(coh);
    vel.add(avoid);
    vel.add(escape);    
    
    return vel;   
  } 

  // finds all neighbours closer than BOID_VICINITY
  public ArrayList<Boid> findNeighbors(ArrayList<Boid> boids, float vicinity) {
    ArrayList<Boid> neighbors = new ArrayList<Boid>();
    for (Boid other : boids) {
      float d = PVector.dist(position, other.position);
      if ((d > 0) && (d < vicinity) && !(other instanceof Predator)) {     
        neighbors.add(other);
      }
    }

    return neighbors;
  }  

  public ArrayList<Predator> findClosePredators(ArrayList<Boid> boids) {
    ArrayList<Predator> closePredators = new ArrayList<Predator>();
    for (Boid other : boids) {
      float d = PVector.dist(position, other.position);      
      if ((d > 0) && (d < BOID_VICINITY * 2) && (other instanceof Predator)) {
        closePredators.add((Predator)other);
      }
    }

    return closePredators;
  }

  public PVector calculateSeparationForce(ArrayList<Boid> boids) {
    PVector sep = new PVector(0, 0);

    for (Boid other : boids) {
      PVector diff = PVector.sub(position, other.position);
      diff.normalize();
      diff.div(PVector.dist(position, other.position));
      sep.add(diff);
    }

    if (boids.size() > 0) {
      sep.normalize();     
    }

    return sep;
  }

  public PVector calculateAlignmentForce(ArrayList<Boid> boids) {
    PVector align = new PVector(0, 0);
    for (Boid other : boids) {
      align.add(other.velocity);
    }

    if (boids.size() > 0) {
      align.normalize();
    }    

    return align;
  }

  public PVector calculateCohesionForce(ArrayList<Boid> boids) {
    PVector coh = new PVector(0, 0);
    for (Boid other : boids) {
      coh.add(other.position);
    }

    if (boids.size() > 0) {
      coh.div(boids.size());
      coh = PVector.sub(coh, position);
      coh.normalize();
    }            

    return coh;
  }  

  public PVector calculateAvoidanceForce(ArrayList<Obstacle> obstacles) {
    PVector ahead = PVector.add(position, PVector.mult(velocity, obstacleLookahead));    
    Obstacle closest = getClosestObstacle(ahead, obstacles);
    if (closest == null) {
      return new PVector(0, 0);
    }               

    PVector avoid = PVector.sub(ahead, closest.position);
    avoid.normalize();

    return avoid;
  }  

  public Obstacle getClosestObstacle(PVector ahead, ArrayList<Obstacle> obstacles) {    
    Obstacle closest = null;
  
    for (Obstacle obstacle : obstacles) {
      float distance = obstacle.position.dist(ahead);
      if (circleLineIntersect(position.x, position.y, ahead.x, ahead.y, obstacle.position.x, obstacle.position.y, obstacle.radius) && 
         (closest == null || obstacle.position.dist(position) < closest.position.dist(position))) {
        closest = obstacle;
      }      
    }             

    return closest;
  }  

  public PVector calculateEscapeForce(ArrayList<Predator> predators) {
    PVector esc = new PVector(0, 0);

    for (Predator predator : predators) {
      PVector diff = PVector.sub(position, predator.position);
      diff.normalize();
      esc.add(diff);
    }

    if (predators.size() > 0) {
      esc.normalize();      
    }    

    return esc;
  }

  public void move() {   
    velocity.normalize();
    velocity.mult(maxSpeed);    
    position.add(velocity);
  }

  // GUI Rendering

  public void borders() {
    if (position.x < -BOID_RADIUS) position.x = width+BOID_RADIUS;
    if (position.y < -BOID_RADIUS) position.y = height-70+BOID_RADIUS;
    if (position.x > width+BOID_RADIUS) position.x = -BOID_RADIUS;
    if (position.y > height-70+BOID_RADIUS) position.y = -BOID_RADIUS;
  }    

  public void render() {
    float theta = velocity.heading() + radians(90);

    setColors();
    pushMatrix();
    translate(position.x, position.y);
    rotate(theta);
    beginShape(TRIANGLES);
    vertex(0, -BOID_RADIUS*2);
    vertex(-BOID_RADIUS, BOID_RADIUS*2);
    vertex(BOID_RADIUS, BOID_RADIUS*2);
    endShape();
    popMatrix();
  }

  public void setColors() {
    fill(200, 100);
    stroke(255);
  }

  public String toString() {
    return "position: " + position + ", velocity: " + velocity;
  }  
}


class Flock {
  ArrayList<Boid> boids;
  ArrayList<Obstacle> obstacles;
    
  Flock() {
    boids = new ArrayList<Boid>();
    obstacles = new ArrayList<Obstacle>();
  }
  
  public void run() {
    for (Boid b: boids) {
       b.run(boids, obstacles);
    } 
    
    for (Obstacle o: obstacles) {
       o.render();      
    }
  }
  
  public void addBoid(Boid b) {
     boids.add(b); 
  }
  
  public void addObstacle(int x, int y) {
    for (Obstacle o: obstacles) {
      if (inCircle(x, y, o.position.x, o.position.y, o.radius)) {
        obstacles.remove(o);
        return;
      }
    }
    
    obstacles.add(new Obstacle(new PVector(x,y)));    
  }
  
  public void deletePredators() {
    ArrayList<Boid> boidsCopy = new ArrayList<Boid>(boids);
    
    for (Boid b: boidsCopy) {
      if (b instanceof Predator) {
        boids.remove(b);
      }
    }       
  }
  
  public boolean inCircle( float mx, float my, float cx, float cy, float circleDia ) {
    float distance = dist(mx, my, cx, cy);
    if (distance > circleDia/2) {
      return false;
    } 
    else {
      return true;
    }
  }  
  
}


Flock flock;

float separationWeight = 1.0f;
float alignmentWeight = 1.0f;
float cohesionWeight = 1.0f;
float avoidanceWeight = 1000.0f;
float escapeWeight = 10.0f;

int selectedDropItem = 1;

public void setup() {
  size(1000, 600);
  flock = new Flock();
  
  for (int i = 0; i < 350; i++) {
    flock.addBoid(new Boid(random(width),random(height)));
  }  
  
  drawGUI();
}

public void draw() {
  background(50);
  flock.run();
}

public void mousePressed() {
  if (mouseY < height - 70) {
    if (selectedDropItem == 1) {
      flock.addObstacle(mouseX, mouseY);
    } else if (selectedDropItem == 2) {
      flock.addBoid(new Predator(mouseX, mouseY));
    }  
  } 
}

public void clearButtonPressed() {
  if (selectedDropItem == 1) {
    flock.obstacles.clear();
  } else if (selectedDropItem == 2) {
    flock.deletePredators();
  }
}
GSlider sepSl, alignSl, cohSl;
GLabel sepLab, alignLab, cohLab;
GToggleGroup dropGroup;
GOption dropObstacle, dropPredator;
GButton clearButton;

public void drawGUI() {
  sepLab = new GLabel(this, 10, height - 60, 110, 20);
  sepLab.setText("Separation");
  sepLab.setLocalColorScheme(4);  
  sepSl = new GSlider(this, 10, height - 70, 200, 100, 15); 
  sepSl.setLocalColorScheme(4);  
  sepSl.setNbrTicks(3);  
  sepSl.setShowValue(true); 
  sepSl.setShowTicks(true); 
  sepSl.setEasing(1.0f); 
  sepSl.setLimits(0.7f, 1.3f);
  sepSl.setValue(separationWeight); 
  
  alignLab = new GLabel(this, 230, height - 60, 110, 20);
  alignLab.setText("Alignment");
  alignLab.setLocalColorScheme(4);  
  alignSl = new GSlider(this, 230, height - 70, 200, 100, 15); 
  alignSl.setLocalColorScheme(4);  
  alignSl.setNbrTicks(3);  
  alignSl.setShowValue(true); 
  alignSl.setShowTicks(true); 
  alignSl.setEasing(1.0f); 
  alignSl.setLimits(0.0f, 2.0f);
  alignSl.setValue(alignmentWeight);   
  
  cohLab = new GLabel(this, 440, height - 60, 110, 20);
  cohLab.setText("Cohesion");
  cohLab.setLocalColorScheme(4);  
  cohSl = new GSlider(this, 440, height - 70, 200, 100, 15); 
  cohSl.setLocalColorScheme(4);  
  cohSl.setNbrTicks(3);  
  cohSl.setShowValue(true); 
  cohSl.setShowTicks(true); 
  cohSl.setEasing(1.0f); 
  cohSl.setLimits(0.7f, 1.3f);
  cohSl.setValue(cohesionWeight);   

  dropGroup = new GToggleGroup();
  
  dropObstacle = new GOption(this, 650, height-40, 70, 20);
  dropObstacle.setTextAlign(GAlign.LEFT, GAlign.MIDDLE);
  dropObstacle.setText("Obstacle");  
  dropObstacle.setLocalColorScheme(4);
  dropObstacle.tag = "obstacle";
  dropObstacle.tagNo = 1;
  dropGroup.addControl(dropObstacle);
  
  dropPredator = new GOption(this, 650, height-20, 70, 20);
  dropPredator.setTextAlign(GAlign.LEFT, GAlign.MIDDLE);
  dropPredator.setText("Predator");  
  dropPredator.setLocalColorScheme(4);
  dropPredator.tag = "predator";
  dropPredator.tagNo = 2;  
  dropGroup.addControl(dropPredator);
  
  dropObstacle.setSelected(true);
  
  clearButton = new GButton(this, 740, height-30, 50, 20);
  clearButton.setLocalColorScheme(4);
  clearButton.setText("Clear");
}

public void handleSliderEvents(GValueControl slider, GEvent event) {
  if (slider.equals(sepSl)) {
    separationWeight = slider.getValueF();
  } else if (slider.equals(alignSl)) {
    alignmentWeight = slider.getValueF();    
  } else if (slider.equals(cohSl)) {
    cohesionWeight = slider.getValueF();    
  }
}

public void handleToggleControlEvents(GToggleControl option, GEvent event) {
 selectedDropItem = option.tagNo; 
}

public void handleButtonEvents(GButton button, GEvent event) {
  clearButtonPressed();
}

// adopted from http://www.openprocessing.org/sketch/8009
public boolean circleLineIntersect(float x1, float y1, float x2, float y2, float cx, float cy, float cr ) {
  float dx = x2 - x1;
  float dy = y2 - y1;
  float a = dx * dx + dy * dy;
  float b = 2 * (dx * (x1 - cx) + dy * (y1 - cy));
  float c = cx * cx + cy * cy;
  c += x1 * x1 + y1 * y1;
  c -= 2 * (cx * x1 + cy * y1);
  c -= cr * cr;
  float bb4ac = b * b - 4 * a * c;
  if (bb4ac < 0) {  // Not intersecting
    return false;
  } else {
    float mu = (-b + sqrt( b*b - 4*a*c )) / (2*a);
    float ix1 = x1 + mu*(dx);
    float iy1 = y1 + mu*(dy);
    mu = (-b - sqrt(b*b - 4*a*c )) / (2*a);
    float ix2 = x1 + mu*(dx);
    float iy2 = y1 + mu*(dy);
   
    // The intersection points
    //ellipse(ix1, iy1, 10, 10);
    //ellipse(ix2, iy2, 10, 10);
     
    float testX;
    float testY;
    // Figure out which point is closer to the circle
    if (dist(x1, y1, cx, cy) < dist(x2, y2, cx, cy)) {
      testX = x2;
      testY = y2;
    } else {
      testX = x1;
      testY = y1;
    }
     
    if (dist(testX, testY, ix1, iy1) < dist(x1, y1, x2, y2) || dist(testX, testY, ix2, iy2) < dist(x1, y1, x2, y2)) {
      return true;
    } else {
      return false;
    }
  }
}    
class Obstacle {
  PVector position;  
  float radius = 20;
  
  Obstacle(PVector position) {
    this.position = position;
  }
  
  public String toString() {
    return "position: " + position;
  }  
  
  public void render() {
    fill(200, 100);
    stroke(255);      
    ellipse(position.x, position.y, radius, radius);    
  }
}

class Predator extends Boid {  
  Predator(float x, float y) {
     super(x,y);
     
     maxSpeed = 2.5f;
     obstacleLookahead = 10;
  }
  
  public PVector updateBoid(ArrayList<Boid> boids, ArrayList<Obstacle> obstacles) {
    ArrayList<Boid> neighbors = findNeighbors(boids, 100.0f);
    
    PVector coh = calculateCohesionForce(neighbors);
    PVector avoid = calculateAvoidanceForce(obstacles);   
    
    avoid.mult(avoidanceWeight); 
   
    PVector vel = new PVector(0,0);    
    vel.add(coh);
    vel.add(avoid);

    return vel;
  }   
  
  public void setColors() {
    fill(204, 102, 0);
    stroke(204, 102, 0);  
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "flocking" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
